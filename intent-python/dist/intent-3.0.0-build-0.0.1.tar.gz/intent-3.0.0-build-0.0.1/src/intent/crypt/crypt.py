import rsa
from stdiomask import getpass
from intent.utils.config_helper import get_config
from intent.utils.log_helper import log_setup, get_logger
import json
import pickle
import base64

log = get_logger(__name__)

# log_setup()


def encrypt(filename: str):
    """
    :return: None
    """
    config_encrypt = get_config('encrypt')

    publicKey, privateKey = rsa.newkeys(int(config_encrypt['key_bits']))

    username = input("Enter the username")

    password = getpass(prompt='Enter the Password', mask='*')

    encMessage = rsa.encrypt(password.encode(),
                             publicKey)


    dict_mongodb = {
          "username": username,
          "passcode": encode_data({
          "password": encMessage,
          "publicKey": publicKey.save_pkcs1(format='DER'),
          "privatekey": privateKey.save_pkcs1(format='DER')})
      }

    json_str = json.dumps(dict_mongodb, indent=1)

    with open(filename, "w") as outfile:
        outfile.write(json_str)

    log.info(f"Updated Details {dict_mongodb}")


def decrypt_credentials(filename: str):
    """

    :return: {username, password}
    """

    log.info('Connecting to Mongo DB')

    with open(filename, 'r') as f:
        config_collection = json.load(f)

    log.info(f"config_collection: {config_collection}")
    passcode = decode_data(config_collection['passcode'])

    privatekey = rsa.PrivateKey.load_pkcs1(passcode['privatekey'], "DER")

    decMessage = rsa.decrypt(passcode['password'], privatekey).decode()
    
    log.info(f"passcode: {passcode}")

    return {'username': config_collection['username'], 'password': decMessage}


def encode_data(data):
    pickled = pickle.dumps(data)
    pickled_b64 = base64.b64encode(pickled)
    return pickled_b64.decode('utf-8')


def decode_data(data):
    return pickle.loads(base64.b64decode(data.encode()))