import time
import csv
import re
import json
import urllib3
import pandas as pd
from math import log
from operator import itemgetter
from nltk.cluster.util import cosine_distance
from bson import json_util
import configparser
from textblob import TextBlob
from collections import Counter
from flask import request
from sklearn.decomposition import TruncatedSVD
import nltk
from gensim.models import Word2Vec
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
import gensim
from gensim.scripts.glove2word2vec import glove2word2vec
from pymongo import MongoClient
from intent.related_tickets.related_tickets_seach_batch import RelatedSearch
from intent.related_tickets.textRankSearch import TextRankSearch
from intent.persistence.mongodbpersistence import MongoDBPersistence
from intent.utils.log_helper import get_logger, log_setup

customer_id = 1
dataset_id = 1

logging = get_logger(__name__)


class MappingPersistence(object):
    @staticmethod
    def get_mapping_details(customer_id):
        itsm_details = MongoDBPersistence.itsm_details_tbl.find_one({}, {"_id":0, "ITSMToolName":1})
        itsm_tool_name = itsm_details['ITSMToolName']
        field_mapping = MongoDBPersistence.mapping_tbl.find_one({"Source_ITSM_Name": itsm_tool_name}, {"_id":0})
        return field_mapping

class relatedticket(object):

    @staticmethod
    def startProcess():
        from time import time 
        start_time = time()
        print("inside start process")
        config_values = MongoDBPersistence.configuration_values_tbl.find_one({}, {"Related_Tickets_Algorithm": 1, "_id": 0}) 
        list_search_algorithms=['textRank', 'word2Vec', 'doc2Vec', 'BERT']
        logging.info(f"search_algorithms: {list_search_algorithms}")

        realTimeincidents=list(MongoDBPersistence.rt_tickets_tbl.find({"user_status" : {"$in":["Not Approved"]}},{'number':1,'_id':0,'assignment_group':1,'opened_by':1,"CustomerID":1, "DatasetID" :1 }))
        realTimeApprovedincidents=list(MongoDBPersistence.rt_tickets_tbl.find({"state": {"$nin": ["closed"]}, "user_status":{"$in":["Approved"]}},{'number':1,'_id':0,'assignment_group':1,'opened_by':1,"CustomerID":1, "DatasetID" :1 }))
        realTimeincidents.extend(realTimeApprovedincidents)
        print("here results ",realTimeincidents)

        RT_Ticket_Numbers = MongoDBPersistence.related_tickets_tbl.find({"Algorithm_name":"BERT"},{"RT_Ticket_Number": 1, "_id": 0}) 
        Related_Ticket_number = [RT_Tickets['RT_Ticket_Number'] for RT_Tickets in RT_Ticket_Numbers]

        realTimeincidents_updated = []
        for num in realTimeincidents:
            incident_number=(num['number'])
            if incident_number in Related_Ticket_number:
                continue
            else:
                realTimeincidents_updated.append(num)

        #assuming all the real time incidents has same set of  column names and values 
        #check for 'assignmentgroup' and 'createdby' in dispalyField List should be same in TblIncident Training and RtIncident Table
        if(realTimeincidents_updated):
            for search_algorithm in list_search_algorithms:
                logging.info(f"Running {search_algorithm} algorithm")
                related_tic_flag = "textrank_related_tic_flag"

                if search_algorithm == "word2Vec":
                    related_tic_flag = "word2vec_related_tic_flag"
                if search_algorithm == "doc2Vec":
                    related_tic_flag = "doc2vec_related_tic_flag"
                if search_algorithm == "BERT":
                    related_tic_flag = "BERT_related_tic_flag"

                if 'assignment_group' and 'createdby' in realTimeincidents_updated[0]:
                    for num in realTimeincidents_updated:
                        try:
                            incident_number=(num['number'])
                            rt_assignemnt_group=(num['assignment_group'])
                            rt_created_by=(num['createdby'])
                            customer_id= num["CustomerID"]
                            dataset_id = num["DatasetID"]
                            if(search_algorithm=="word2Vec" or search_algorithm =="doc2Vec" or search_algorithm == "BERT" ):
                                relatedResults=RelatedSearch.getRelatedTickets(customer_id, dataset_id, incident_number,search_algorithm,rt_assignemnt_group)
                                #relatedResults=RelatedTicket.getRelatedTickets(customer_id, dataset_id, incident_number)
                                print("closedresults from startProcess",relatedResults)
                                relatedOpenResults=RelatedSearch.getRelatedOpenTickets(customer_id, dataset_id, incident_number,search_algorithm)
                                print("open results from startProcess",relatedOpenResults)
                            else:
                                relatedResults=TextRankSearch.getRelatedTickets(customer_id, dataset_id, incident_number)
                                print("related_results using TextRankSearch.py",relatedResults)
                                relatedOpenResults=TextRankSearch.getRelatedOpenTickets(customer_id, dataset_id, incident_number)
                                print("related_openresults using TextRankSearch.py",relatedOpenResults)
                            logging.info(
                                f"insering algorithm name: {search_algorithm} in related_tickets for ticket_number: {incident_number}")
                            MongoDBPersistence.related_tickets_tbl.insert_one({"RT_Ticket_Number":incident_number,'Related_ticket_info':relatedResults,'Related_Open_ticket_info':relatedOpenResults,'Algorithm_name':search_algorithm})
                            MongoDBPersistence.rt_tickets_tbl.update_one({"CustomerID":customer_id,"number":incident_number},{"$set":{related_tic_flag:True}})
                        except Exception as e:
                            print('exception in main function.......',e)
                            MongoDBPersistence.rt_tickets_tbl.update_one({"CustomerID":customer_id,"number":incident_number},{"$set":{related_tic_flag:"Could not Processed"}})
                            logging.info("Skipped this %s incident because of following exception-  %s  " % (num['number'],str(e)))
                            continue 
                elif 'assignment_group' in realTimeincidents_updated[0] and 'createdby' not  in realTimeincidents_updated[0]:
                    for num in realTimeincidents_updated:
                        try:
                            incident_number=(num['number'])
                            rt_assignemnt_group=(num['assignment_group'])
                            customer_id= num["CustomerID"]
                            dataset_id = num["DatasetID"]
                            # createdby=(num['createdby'])
                            if(search_algorithm=="word2Vec" or search_algorithm =="doc2Vec" or search_algorithm == "BERT"):
                                relatedResults=RelatedSearch.getRelatedTickets(customer_id, dataset_id, incident_number,search_algorithm,rt_assignemnt_group)
                                #relatedResults=RelatedTicket.getRelatedTickets(customer_id, dataset_id, incident_number)
                                print("closedresults from startProcess",relatedResults)
                                relatedOpenResults=RelatedSearch.getRelatedOpenTickets(customer_id, dataset_id, incident_number,search_algorithm)
                                print("open results from startProcess",relatedOpenResults)
                            else:
                                relatedResults=TextRankSearch.getRelatedTickets(customer_id, dataset_id, incident_number)
                                print("related_results using TextRankSearch.py",relatedResults)
                                relatedOpenResults=TextRankSearch.getRelatedOpenTickets(customer_id, dataset_id, incident_number)
                                print("related_openresults using TextRankSearch.py",relatedOpenResults)
                            logging.info(
                                f"insering algorithm name: {search_algorithm} in related_tickets for ticket_number: {incident_number}")
                            MongoDBPersistence.related_tickets_tbl.insert_one({"RT_Ticket_Number":incident_number,'Related_ticket_info':relatedResults,'Related_Open_ticket_info':relatedOpenResults,'Algorithm_name':search_algorithm})
                            MongoDBPersistence.rt_tickets_tbl.update_one({"CustomerID":customer_id,"number":incident_number},{"$set":{related_tic_flag:True}})
                        except Exception as e:
                            print('exception in main function.......',e)
                            MongoDBPersistence.rt_tickets_tbl.update_one({"CustomerID":customer_id,"number":incident_number},{"$set":{related_tic_flag:"Could not Processed"}})
                            logging.info("Skipped this %s incident because of following exception-  %s  " % (num['number'],str(e)))
                            continue 
                else:
                    for num in realTimeincidents_updated:
                        try:
                            incident_number=(num['number'])
                            customer_id= num["CustomerID"]
                            dataset_id = num["DatasetID"]
                            rt_assignemnt_group=(num['assignment_group'])
                            # assignemnt_group=(num['assignmentgroup'])
                            # createdby=(num['createdby'])
                            if(search_algorithm=="word2Vec" or search_algorithm =="doc2Vec" or search_algorithm == "BERT"):
                                relatedResults=RelatedSearch.getRelatedTickets(customer_id, dataset_id, incident_number,search_algorithm,rt_assignemnt_group)
                                #relatedResults=RelatedTicket.getRelatedTickets(customer_id, dataset_id, incident_number)
                                print("closedresults from startProcess",relatedResults)
                                relatedOpenResults=RelatedSearch.getRelatedOpenTickets(customer_id, dataset_id, incident_number,search_algorithm)
                                print("open results from startProcess",relatedOpenResults)
                            else:
                                relatedResults=TextRankSearch.getRelatedTickets(customer_id, dataset_id, incident_number)
                                print("related_results using TextRankSearch.py",relatedResults)
                                relatedOpenResults=TextRankSearch.getRelatedOpenTickets(customer_id, dataset_id, incident_number)
                                print("related_openresults using TextRankSearch.py",relatedOpenResults)
                            logging.info(f"insering algorithm name: {search_algorithm} in related_tickets for ticket_number: {incident_number}")
                            MongoDBPersistence.related_tickets_tbl.insert_one({"RT_Ticket_Number":incident_number,'Related_ticket_info':relatedResults,'Related_Open_ticket_info':relatedOpenResults,'Algorithm_name':search_algorithm})
                            MongoDBPersistence.rt_tickets_tbl.update_one({"CustomerID":customer_id,"number":incident_number},{"$set":{related_tic_flag:True}})
                        except Exception as e:
                            print('exception in main function.......',e)
                            MongoDBPersistence.rt_tickets_tbl.update_one({"CustomerID":customer_id,"number":incident_number},{"$set":{related_tic_flag:"Could not Processed"}})
                            logging.info("Skipped this %s incident because of following exception-  %s  " % (num['number'],str(e)))
                            continue 
        else:
            logging.info("No new incident found in IncidentRT table")
            print("No new incident found in IncidentRT table")
    
        end_time = time()
        seconds_elapsed = end_time - start_time
        logging.info("Time taken: %s " % (seconds_elapsed))
        print("Time taken:", seconds_elapsed)

   