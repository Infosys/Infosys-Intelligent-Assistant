__created__ = "Mar 19, 2019"
__copyright__ = "Copyright 2019-20, Infosys Ltd., Internal, Confidential"
from intent.restservice import RestService
from intent.persistence.mongodbpersistence import MongoDBPersistence
from intent.utils.log_helper import get_logger, log_setup

# log_setup()

logging = get_logger(__name__)

class MappingPersistence(object):

    def __init__(self):
        pass

    @staticmethod
    def get_mapping_details(customer_id):
        itsm_details = MongoDBPersistence.itsm_details_tbl.find_one({}, {"_id":0, "ITSMToolName":1})
        logging.info(f"itsm_details: {itsm_details}")
        itsm_tool_name = itsm_details['ITSMToolName']
        field_mapping = MongoDBPersistence.mapping_tbl.find_one({"CustomerID":customer_id, "Source_ITSM_Name": itsm_tool_name}, {"_id":0})
        logging.info(f"field_mapping: {field_mapping}")
        return field_mapping