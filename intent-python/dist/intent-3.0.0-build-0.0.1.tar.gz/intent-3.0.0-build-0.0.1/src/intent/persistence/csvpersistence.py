__created__ = "Mar 19, 2019"
__copyright__ = "Copyright 2019-20, Infosys Ltd., Internal, Confidential"
'''
Created on Sep 5, 2018

@author: Rajagopal_Neralla
'''
from builtins import print

class CSVPersistence(object,):
    def __init__(self,config):
        #Do Nothing;
        self.config=config;
        print("CSVPresistence.__init__")
    def readList(self,name):
        #Do Nothing
        print("CSVPresistence.readList")
    #Read the stop words from CSV file
    def readStopWords(self):
        print("Reading Stop Words From CSV");
        import csv
        #from curses.has_key import python
        with open('./../data/stopwords.csv', 'r') as readFile:
            reader = csv.reader(readFile)
            list1 = list(reader)
            STOP_WORDS = list1[0]
            readFile.close()
            len(STOP_WORDS)
            return STOP_WORDS;            
        print("Done Reading Stop Words From CSV");
    #End readStopWordsFromCSV
    def readIncidentData(self):
        # Load ticket data
        print("readIncidentData")
        import pandas as pd
        #df=pd.read_csv('./../data/Ticket_Dump_v2_ForFT.csv',encoding='latin-1')
        df=pd.read_csv('./../data/Ticket_Dump_v2_half.csv',encoding='latin-1')
        
        #df.head(20)
        #df.count()                
        print("Done reading IncidentData")
        return df