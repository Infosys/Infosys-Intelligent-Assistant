__created__ = "Mar 19, 2019"
__copyright__ = "Copyright 2019-20, Infosys Ltd., Internal, Confidential"
'''
Created on Sep 5, 2018

@author: Rajagopal_Neralla
'''
from intent.persistence.csvpersistence import CSVPersistence
from intent.persistence.sqlpersistence import SQLPersistence
from intent.persistence.mongodbpersistence import MongoDBPersistence

class PeristenceManager(object):
    def __init__(self):
        #Do Nothing;
        print("PeristenceManager.__init__")
    @staticmethod
    def getPeristenceManager():
        #Do Nothing
        global config
        import configparser
        config = configparser.RawConfigParser();
        config.read('config/Intent.ini');
        pesistenceType = config.get('Persistence', 'persistenceType');
        global pesistenceManager
        if(pesistenceType=="CSV"):
            pesistenceManager= CSVPersistence(config);
        elif(pesistenceType=="MySQL"):
            pesistenceManager= SQLPersistence(config);
        elif(pesistenceType=="Mongo"):
            pesistenceManager= MongoDBPersistence(config);     
        return pesistenceManager
    @staticmethod
    def getPeristenceManagerByType(pesistenceType):
        #Do Nothing        
        global config
        import configparser
        config = configparser.RawConfigParser();
        config.read('config/Intent.ini');
        if(pesistenceType=="CSV"):
            pesistenceManager= CSVPersistence(config);
        elif(pesistenceType=="MySQL"):
            pesistenceManager= SQLPersistence(config);
        elif(pesistenceType=="Mongo"):
            pesistenceManager= MongoDBPersistence(config);     
        return pesistenceManager