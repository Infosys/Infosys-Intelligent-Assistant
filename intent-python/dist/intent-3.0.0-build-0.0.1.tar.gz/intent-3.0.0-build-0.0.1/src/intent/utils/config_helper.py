from configparser import ConfigParser

from intent.utils.log_helper import log_setup, get_logger

log = get_logger(__name__)
# log_setup()

config_file_path = 'config/Intent.ini'


def get_config(key: str=None) -> dict:
    try:
        log.debug(f"key: {key}")
        log.debug(config_file_path)
        config_file = ConfigParser()
        config_file.read(config_file_path)
        config = config_file.__dict__['_sections'].copy()
        log.debug(config)
        if key is not None:
            return config[key]
        else:
            return config
    except Exception as e:
        log.error(e)
        return {}