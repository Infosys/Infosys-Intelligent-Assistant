__created__ = "Mar 19, 2019"
__copyright__ = "Copyright 2019-20, Infosys Ltd., Internal, Confidential"
name = "intent"