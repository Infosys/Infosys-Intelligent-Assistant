from intent.persistence.mongodbpersistence import MongoDBPersistence
from intent.recommendation.knowledgearticles import KnowledgeArticle
from intent.related_tickets.related_tickets_search import relatedticket
import atexit
from apscheduler.schedulers.background import BackgroundScheduler

scheduler = BackgroundScheduler()
scheduler.start()
atexit.register(lambda: scheduler.pause())

class SchedulerJobs(object):
    '''
    classdocs
    '''

    def __init__(self, params):
        '''
        Constructor
        '''
    @staticmethod
    def run_jobs():
        cron_settings = list(MongoDBPersistence.customer_tbl.find({},{"RTJobSettings":1,
                                                                 "KBJobSettings":1,
                                                                 "CustomerID":1,
                                                                 "_id":0}))

        if cron_settings:
            for cron_setting in cron_settings:
                if cron_setting.get("RTJobSettings"):
                    print(cron_setting['RTJobSettings'])
                    scheduler.add_job(relatedticket.startProcess, trigger="interval",
                                      id=cron_setting['RTJobSettings']['job_id'],
                                      seconds=cron_setting['RTJobSettings']['TimeInterval'])
                if cron_setting.get("KBJobSettings"):
                    print(cron_setting['KBJobSettings'])
                    scheduler.add_job(KnowledgeArticle.getKnowledgeArticle, trigger="interval",
                                      args=[cron_setting['CustomerID']],
                                     id=cron_setting['KBJobSettings']['job_id'],
                                     seconds=cron_setting['KBJobSettings']['TimeInterval'])

            print(scheduler.get_jobs())


SchedulerJobs.run_jobs()